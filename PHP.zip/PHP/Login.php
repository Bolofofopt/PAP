<?php


// Conexão com a BD
$servername = "localhost";
$username = "mtgei21epvr_wphuser";
$password = "P@ssw0rdg02";
$dbname = "mtgei21epvr_grupo02_DB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Inicia a sessão
session_start();

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}


// Processa os dados do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $Password = $_POST['Password'];
    $EncryptedPassword = md5($Password);

    // Prepara a consulta para verificar se o email e a senha estão corretos
    $stmt = $conn->prepare("SELECT * FROM Cliente WHERE email = ? AND Password = ?");
    $stmt->bind_param("ss", $email, $EncryptedPassword);

    // Executa a consulta
    $stmt->execute();

    // Obtém o resultado
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Se os detalhes estiverem corretos, inicia a sessão
        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        echo "Login bem sucedido!";
    
     wp_redirect( 'https://tgei21.epvr4.net/formulario/' );
        exit;

    }
    else 
    {
        // Se os detalhes estiverem incorretos, mostra uma mensagem de erro
        echo "Email ou senha incorretos!";
    }

    // Fecha a declaração
    $stmt->close();
}
?>
