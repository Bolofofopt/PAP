<?php
/*----------------------------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------Conexão_BD-----------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

$servername = "localhost";
$username = "mtgei21epvr_wphuser";
$password = "P@ssw0rdg02";
$dbname = "mtgei21epvr_grupo02_DB";

$conn = new mysqli($servername, $username, $password, $dbname);

/*----------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------VerificaAconexão------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

/*----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------BuscarAsRespostarAoFormulário-------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nomeCliente = $_POST['PrimeiroNome'];
  $material = $_POST['material'];
  $medidas = $_POST['medidas'];
  // as variáveis $material e $medidas conforme necessário
}



/*----------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------SelectDoCliente-------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

$sql = "SELECT Cliente.IDcliente, Cliente.PrimeiroNome FROM Cliente WHERE Cliente.PrimeiroNome = '$nomeCliente'";

$result = $conn->query($sql);

$nomeCliente = ""; 

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $idCliente = $row["IDcliente"];
    $nomeCliente = $row["PrimeiroNome"]; 
  }
} else {
  echo "Nenhum cliente encontrado";
}

/*----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------OutputDoFornecedor------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

$sql = "SELECT Fornecedor.NomeFornecedor, Fornecedor.EmailFornecedor, Fornecedor.MoradaFornecedor FROM Fornecedor 
        JOIN caixas ON Fornecedor.IDcaixa = caixas.IDcaixa
        JOIN TipoDeCaixa ON caixas.IDtipodecaixa = TipoDeCaixa.IDtipodecaixa 
        WHERE TipoDeCaixa.colDescricaoCaixa = '$material' AND caixas.Medidas = '$medidas';";

$result = $conn->query($sql);

$nomeFornecedor = ""; 

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "<br>";
    echo "Nome do Fornecedor: " . $row["NomeFornecedor"]. "<br>";
    echo "Email do Fornecedor: " . $row["EmailFornecedor"]. "<br>";
    echo "Morada do Fornecedor: " . $row["MoradaFornecedor"]. "<br>";
    $nomeFornecedor = $row["NomeFornecedor"]; 
  }
} else {
  echo "Nenhum resultado encontrado";
}

/*----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------InsertNaTabelaEncomenda-------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

// Buscar IDFornecedor
$sql = "SELECT Fornecedor.IDfornecedor FROM Fornecedor WHERE Fornecedor.NomeFornecedor = '$nomeFornecedor'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $idFornecedor = $row["IDfornecedor"];
  }
} else {
  echo "Nenhum fornecedor encontrado";
}

// Criar um novo IDEncomenda

// Buscar o maior IDencomenda atual
$sql = "SELECT MAX(IDencomenda) as max_id FROM Encomenda";
$result = $conn->query($sql);

$next_id = 1; // Inicializar com 1

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $next_id = $row["max_id"] + 1; // Incrementar o maior IDencomenda atual
}

// Inserir uma nova encomenda
$sql = "INSERT INTO Encomenda (IDfornecedor, IDcliente, IDencomenda) VALUES ('$idFornecedor', '$idCliente', '$next_id')";

if ($conn->query($sql) === TRUE) {
    echo "Nova encomenda criada com sucesso. O número da encomenda é: " . $next_id;
} else {
  echo "Erro: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>