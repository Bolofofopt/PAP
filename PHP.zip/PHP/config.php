<?php

// Conexão com a BD
$servername = "localhost";
$username = "mtgei21epvr_client";
$password = "P@ssw0rd+client";
$dbname = "mtgei21epvr_grupo02_DB";



// Cria conexão
$conn = new mysqli($servername, $username, $password, $dbname);
// Verifica a conexão
if($link === false){
    die("ERRO: Não foi possível conectar. " . mysqli_connect_error());
}
?>