  <?php
// Conexão com a BD
$servername = "localhost";
$username = "mtgei21epvr_wphuser";
$password = "P@ssw0rdg02";
$dbname = "mtgei21epvr_grupo02_DB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $PrimeiroNome = $_POST['PrimeiroNome'];
  $UltimoNome = $_POST['UltimoNome'];
  $email = $_POST['email'];
  $Password = $_POST['Password'];
  $EncryptedPassword = md5($Password);

  // A EncryptedPassword é igual á password encriptada com md5

  // Agora pode usar as variáveis $material e $medidas conforme necessário
}

// Consulta para obter o próximo IDcliente disponível
$sql = "SELECT MAX(IDcliente) AS max_id FROM Cliente";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $next_id = $row["max_id"] + 1;
} else {
    // Se não houver registros, comece com 1
    $next_id = 1;
}


// Processa os dados do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo_caixa = $_POST["tipo_caixa"];
    // Insere
    $sql = "INSERT INTO Cliente (IDcliente, PrimeiroNome, UltimoNome, email, Password)
    VALUES ( $next_id, '$PrimeiroNome', '$UltimoNome', '$email','$EncryptedPassword' )";
    if ($conn->query($sql) === TRUE) {
        echo "Cadastrado com sucesso";
        echo "<br>";
    } else {
        echo "Erro ao cadastrar:" . $conn->error;
    }
}
