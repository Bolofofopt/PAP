<?php
// Conexão com a BD
$servername = "localhost";
$username = "mtgei21epvr_client";
$password = "P@ssw0rd+client";
$dbname = "mtgei21epvr_grupo02_DB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
//seleciona o fornecedor de acordo com a informação que o cliente colocou
/*
$caixa = "Caixa de Plastico";
$medidas = "10x20x15";
$sql = "SELECT Fornecedor.NomeFornecedor FROM Fornecedor 
        JOIN caixas ON Fornecedor.IDcaixa = caixas.IDcaixa
        JOIN TipoDeCaixa ON caixas.IDtipodecaixa = TipoDeCaixa.IDtipodecaixa 
        WHERE TipoDeCaixa.colDescricaoCaixa = '$caixa' AND caixas.Medidas = '$medidas';";
*/

/*----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------BuscarAsRespostarAoFormulário-------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $PrimeiroNome = $_POST['PrimeiroNome'];
  $UltimoNome = $_POST['UltimoNome'];
  $email = $_POST['email'];
  $material = $_POST['material'];
  $medidas = $_POST['medidas'];
  // as variáveis $material e $medidas conforme necessário
}


/*----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------InsertDoClienteNaBD-----------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------------*/

// Consulta para obter o próximo IDcliente disponível
$sql = "SELECT MAX(IDcliente) AS max_id FROM Cliente";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $next_id = $row["max_id"] + 1;
} else {
    // Se não houver registros, comece com 1
    $next_id = 1;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $material = $_POST['material'];
  $medidas = $_POST['medidas'];
  // Agora você pode usar as variáveis $material e $medidas conforme necessário
}



$sql = "SELECT Fornecedor.NomeFornecedor FROM Fornecedor 
        JOIN caixas ON Fornecedor.IDcaixa = caixas.IDcaixa
        JOIN TipoDeCaixa ON caixas.IDtipodecaixa = TipoDeCaixa.IDtipodecaixa 
        WHERE TipoDeCaixa.colDescricaoCaixa = '$material' AND caixas.Medidas = '$medidas';";



$result = $conn->query($sql);


if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "Fornecedor: " . $row["NomeFornecedor"]. "<br>";
  }
} else {
  echo "Nenhum resultado encontrado";
}
$conn->close();
?>